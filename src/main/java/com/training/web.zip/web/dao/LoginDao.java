package com.training.web.dao;

import java.util.List;

import com.training.web.model.User;


public interface LoginDao {

	List<User> getUsers();


	
}
