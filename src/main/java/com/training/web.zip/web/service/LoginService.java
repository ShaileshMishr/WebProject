package com.training.web.service;

public interface LoginService {
	
	boolean isValidUser(String username, String password);

	
}
